﻿using System.Windows;

namespace PolarisBiosEditor
{
    public partial class App : Application
    {
    }
}
